class EmbeddingModelBuilder():
    """
    EmbeddingModelCreater
    """
